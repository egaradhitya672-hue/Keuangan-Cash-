const STORAGE_KEY = 'kaskampus_transactions_v1';
const SESSION_KEY = 'kaskampus_user';
const DEMO_USERNAME = 'mahasiswa';
const DEMO_PASSWORD = 'cash123';
const categories = {
  income: ['Tabungan', 'Uang saku', 'Gaji', 'Lainnya'],
  expense: ['kuliah', 'Hiburan', 'Belanja', 'Lainnya']
};

const loginScreen = document.getElementById('loginScreen');
const appScreen = document.getElementById('appScreen');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const transactionForm = document.getElementById('transactionForm');
const transactionList = document.getElementById('transactionList');
const searchInput = document.getElementById('searchInput');
const filterSelect = document.getElementById('filterSelect');
const typeSelect = document.getElementById('type');
const categorySelect = document.getElementById('category');
let transactions = loadTransactions();
let currentUser = sessionStorage.getItem(SESSION_KEY);

function loadTransactions() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(saved) ? saved.filter(item => item && typeof item.id === 'string' && Number.isFinite(Number(item.amount))) : [];
  } catch {
    return [];
  }
}

function saveTransactions() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  } catch {
    window.alert('Penyimpanan browser tidak tersedia. Transaksi hanya tersimpan sementara.');
  }
}

function formatCurrency(value) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
}

function formatDate(value) {
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
}

function todayString() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function setLoggedIn(isLoggedIn) {
  loginScreen.hidden = isLoggedIn;
  appScreen.hidden = !isLoggedIn;
  if (isLoggedIn) {
    const name = currentUser || 'mahasiswa';
    const displayName = name.charAt(0).toUpperCase() + name.slice(1);
    document.getElementById('greetingName').textContent = displayName;
    document.getElementById('sidebarName').textContent = displayName;
    document.querySelector('.avatar').textContent = displayName.charAt(0).toUpperCase();
    document.getElementById('todayLabel').textContent = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
    renderTransactions();
    renderSummary();
  }
}

function updateCategories() {
  categorySelect.replaceChildren();
  categories[typeSelect.value].forEach(category => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    categorySelect.append(option);
  });
}

function renderSummary() {
  const now = new Date();
  const thisMonth = transactions.filter(item => {
    const date = new Date(`${item.date}T00:00:00`);
    return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
  });
  const allIncome = transactions.filter(item => item.type === 'income').reduce((sum, item) => sum + Number(item.amount), 0);
  const allExpense = transactions.filter(item => item.type === 'expense').reduce((sum, item) => sum + Number(item.amount), 0);
  const monthIncome = thisMonth.filter(item => item.type === 'income').reduce((sum, item) => sum + Number(item.amount), 0);
  const monthExpense = thisMonth.filter(item => item.type === 'expense').reduce((sum, item) => sum + Number(item.amount), 0);
  document.getElementById('balanceValue').textContent = formatCurrency(allIncome - allExpense);
  document.getElementById('incomeValue').textContent = formatCurrency(monthIncome);
  document.getElementById('expenseValue').textContent = formatCurrency(monthExpense);
}

function renderTransactions() {
  const query = searchInput.value.trim().toLocaleLowerCase('id');
  const filter = filterSelect.value;
  const visible = transactions.filter(item => {
    const matchesType = filter === 'all' || item.type === filter;
    const matchesSearch = `${item.description} ${item.category}`.toLocaleLowerCase('id').includes(query);
    return matchesType && matchesSearch;
  }).sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));

  transactionList.replaceChildren();
  document.getElementById('emptyState').hidden = visible.length > 0;
  visible.forEach(item => {
    const row = document.createElement('tr');
    const nameCell = document.createElement('td');
    const name = document.createElement('div');
    name.className = 'transaction-name';
    const icon = document.createElement('span');
    icon.className = `transaction-icon${item.type === 'income' ? ' is-income' : ''}`;
    icon.textContent = item.type === 'income' ? '↙' : '↗';
    const description = document.createElement('span');
    description.textContent = item.description;
    name.append(icon, description);
    nameCell.append(name);

    const categoryCell = document.createElement('td');
    const category = document.createElement('span');
    category.className = 'category-tag';
    category.textContent = item.category;
    categoryCell.append(category);

    const dateCell = document.createElement('td');
    dateCell.textContent = formatDate(item.date);
    const amountCell = document.createElement('td');
    amountCell.className = item.type === 'income' ? 'amount-income' : 'amount-expense';
    amountCell.textContent = `${item.type === 'income' ? '+' : '−'} ${formatCurrency(Number(item.amount))}`;
    const actionCell = document.createElement('td');
    const deleteButton = document.createElement('button');
    deleteButton.type = 'button';
    deleteButton.className = 'delete-transaction';
    deleteButton.textContent = '×';
    deleteButton.title = 'Hapus transaksi';
    deleteButton.setAttribute('aria-label', `Hapus transaksi ${item.description}`);
    deleteButton.addEventListener('click', () => deleteTransaction(item.id));
    actionCell.append(deleteButton);
    row.append(nameCell, categoryCell, dateCell, amountCell, actionCell);
    transactionList.append(row);
  });
}

function deleteTransaction(id) {
  const item = transactions.find(transaction => transaction.id === id);
  if (!item || !window.confirm(`Hapus transaksi "${item.description}"?`)) return;
  transactions = transactions.filter(transaction => transaction.id !== id);
  saveTransactions();
  renderTransactions();
  renderSummary();
}

loginForm.addEventListener('submit', event => {
  event.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (username.toLowerCase() !== DEMO_USERNAME || password !== DEMO_PASSWORD) {
    loginError.textContent = 'Nama pengguna atau kata sandi tidak sesuai.';
    return;
  }
  currentUser = DEMO_USERNAME;
  sessionStorage.setItem(SESSION_KEY, currentUser);
  loginError.textContent = '';
  setLoggedIn(true);
});

document.getElementById('togglePassword').addEventListener('click', event => {
  const passwordInput = document.getElementById('password');
  const showing = passwordInput.type === 'password';
  passwordInput.type = showing ? 'text' : 'password';
  event.currentTarget.textContent = showing ? 'Sembunyi' : 'Lihat';
  event.currentTarget.setAttribute('aria-label', showing ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
});

function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  currentUser = null;
  loginForm.reset();
  loginError.textContent = '';
  setLoggedIn(false);
}

document.getElementById('logoutButton').addEventListener('click', logout);
document.getElementById('topLogoutButton').addEventListener('click', logout);
typeSelect.addEventListener('change', updateCategories);
searchInput.addEventListener('input', renderTransactions);
filterSelect.addEventListener('change', renderTransactions);

transactionForm.addEventListener('submit', event => {
  event.preventDefault();
  const amount = Number(document.getElementById('amount').value);
  const description = document.getElementById('description').value.trim();
  if (!description || !Number.isSafeInteger(amount) || amount < 1) return;
  transactions.push({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    description,
    type: typeSelect.value,
    category: categorySelect.value,
    amount,
    date: document.getElementById('date').value
  });
  saveTransactions();
  transactionForm.reset();
  typeSelect.value = 'expense';
  document.getElementById('date').value = todayString();
  updateCategories();
  renderTransactions();
  renderSummary();
});

document.getElementById('exportButton').addEventListener('click', () => {
  if (transactions.length === 0) {
    window.alert('Belum ada transaksi untuk diekspor.');
    return;
  }
  const escapeCsv = value => `"${String(value).replaceAll('"', '""')}"`;
  const rows = [
    ['Tanggal', 'Nama transaksi', 'Jenis', 'Kategori', 'Jumlah (Rp)'],
    ...transactions.slice().sort((a, b) => a.date.localeCompare(b.date)).map(item => [item.date, item.description, item.type === 'income' ? 'Pemasukan' : 'Pengeluaran', item.category, item.amount])
  ];
  const csv = '\uFEFF' + rows.map(row => row.map(escapeCsv).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'catatan-kas-kampus.csv';
  link.click();
  URL.revokeObjectURL(url);
});

document.getElementById('date').value = todayString();
updateCategories();
setLoggedIn(Boolean(currentUser));
